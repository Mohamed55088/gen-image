import torch
from diffusers import DiffusionPipeline
import warnings
from PIL import Image

warnings.filterwarnings('ignore')

# Load the diffusion pipeline
pipe = DiffusionPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0",
    torch_dtype=torch.float16,
    use_safetensors=True,
    variant="fp16"
)

# Move the pipeline to GPU
pipe.to("cuda")

# Generate the image
prompt = "a mouse is happy"
images = pipe(prompt=prompt)

# Save the image
image = images.images[0]
image.save("generated_image.png")
