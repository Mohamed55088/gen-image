import torch
from diffusers import DiffusionPipeline
import warnings
from flask import Flask, jsonify, request
import base64
from io import BytesIO

warnings.filterwarnings('ignore')

app = Flask(__name__)

# Load the diffusion pipeline model
try:
    pipe = DiffusionPipeline.from_pretrained(
        "stabilityai/stable-diffusion-xl-base-1.0",
        torch_dtype=torch.float16,
        use_safetensors=True,
        variant="fp16"
    )
    pipe.to("cuda")
except torch.cuda.OutOfMemoryError:
    print("CUDA out of memory. Switching to CPU.")
    pipe = DiffusionPipeline.from_pretrained(
        "stabilityai/stable-diffusion-xl-base-1.0",
        torch_dtype=torch.float16,
        use_safetensors=True,
        variant="fp16"
    )
    pipe.to("cpu")

@app.route('/', methods=["POST", "GET"])
def index():
    if request.method == "POST":
        data = request.get_json()
        prompt = data.get('prompt', 'a mouse is happy')

        images = pipe(prompt=prompt).images  # Generate images using the prompt
        image_list = [img.convert("RGB") for img in images]

        # Convert images to base64-encoded strings
        image_data = []
        for img in image_list:
            buffered = BytesIO()
            img.save(buffered, format="JPEG")
            image_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
            image_data.append(image_base64)

        return jsonify({'images': image_data})

    return "Send a POST request with a JSON payload containing the 'prompt'."

if __name__ == '__main__':
    app.run()
